import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Register from "./pages/Register";

import WorkoutLog from "./pages/WorkoutLog"; // Import the WorkoutLog component
import Calories from "./pages/Calories";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import AuthGuard from "./components/AuthGuard";
import Navbar from "./components/Navbar";
 // Import the WorkoutLog component

function App() {
  return (
    <Router>
      <Routes>
      <Route path="/register" element={<Register />} />
        <Route path="/" element={<Login />} />
       
        <Route path="/workouts" element={<WorkoutLog />} />
        <Route path="/calories" element={<Calories />} />

        {/* ✅ Protect Dashboard Route */}
        <Route
          path="/dashboard"
          element={
            <AuthGuard>
              <Dashboard />
            </AuthGuard>
          }
        />
      </Routes>
    </Router>
  );
}

export default App;
