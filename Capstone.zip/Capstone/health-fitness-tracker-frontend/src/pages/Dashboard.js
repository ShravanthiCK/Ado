import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { jwtDecode } from "jwt-decode";

const Dashboard = () => {
  const [user, setUser] = useState({ name: "", email: "" });
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      try {
        const decoded = jwtDecode(token);
        setUser({ name: decoded.name, email: decoded.email });
      } catch (error) {
        console.error("Error decoding token:", error);
        localStorage.removeItem("token");
      }
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  // 🔥 Styling
  const containerStyle = {
    height: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    backgroundImage: `url("https://i.pinimg.com/originals/29/7a/4e/297a4eaef8dc863adcedbbae5f583629.jpg")`, // Change image as needed
    backgroundSize: "cover",
    backgroundPosition: "center",
  };

  const cardStyle = {
    width: "400px",
    padding: "30px",
    borderRadius: "10px",
    backgroundColor: "rgba(255, 255, 255, 0.9)", // Semi-transparent card
    boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.2)",
    textAlign: "center",
  };

  const buttonContainerStyle = {
    display: "flex",
    justifyContent: "space-between",
    marginTop: "15px",
  };

  const buttonStyle = {
    flex: 1,
    margin: "5px",
    padding: "10px",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
  };

  return (
    <div style={containerStyle}>
      <div style={cardStyle}>
        <h2>Welcome to the Dashboard</h2>
        <hr />
        <p><strong>Name:</strong> {user.name}</p>
        <p><strong>Email:</strong> {user.email}</p>

        <div style={buttonContainerStyle}>
          <Link to="/workouts" style={{ ...buttonStyle, backgroundColor: "#007bff", color: "#fff", textAlign: "center", textDecoration: "none", padding: "10px" }}>
            Go to Workouts
          </Link>
          <Link to="/calories" style={{ ...buttonStyle, backgroundColor: "#28a745", color: "#fff", textAlign: "center", textDecoration: "none", padding: "10px" }}>
            Go to Calories
          </Link>
          <button style={{ ...buttonStyle, backgroundColor: "#dc3545", color: "#fff" }} onClick={handleLogout}>
            Logout
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
