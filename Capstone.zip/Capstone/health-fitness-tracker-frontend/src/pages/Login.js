import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    localStorage.setItem("authToken", "dummy_token");
    navigate("/dashboard");
  };

  // 🔥 Inline styles with background image
  const containerStyle = {
    height: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    backgroundImage: `url("https://static1.bigstockphoto.com/0/7/2/large1500/270519103.jpg")`,
    backgroundSize: "cover",
    backgroundPosition: "center",
  };

  const cardStyle = {
    width: "350px",
    padding: "30px",
    borderRadius: "10px",
    backgroundColor: "rgba(255, 255, 255, 0.9)", // Semi-transparent background
    boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.2)",
    textAlign: "center",
  };

  const inputStyle = {
    width: "100%",
    padding: "10px",
    marginBottom: "10px",
    borderRadius: "5px",
    border: "1px solid #ccc",
  };

  const buttonStyle = {
    width: "100%",
    padding: "10px",
    backgroundColor: "#007bff",
    color: "#fff",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    marginTop: "10px",
  };

  const linkStyle = {
    display: "block",
    marginTop: "10px",
    color: "#007bff",
    textDecoration: "none",
    fontWeight: "bold",
  };

  return (
    <div style={containerStyle}>
      <div style={cardStyle}>
        <h2>Login</h2>
        <form onSubmit={handleLogin}>
          <input
            type="email"
            style={inputStyle}
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            style={inputStyle}
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button type="submit" style={buttonStyle}>Login</button>
        </form>

        {/* 🔗 Link to Register page */}
        <Link to="/register" style={linkStyle}>Don't have an account? Register here</Link>
      </div>
    </div>
  );
};

export default Login;
