import React, { useEffect, useState } from "react";
import axios from "axios";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Bar } from "react-chartjs-2";
import { Chart, registerables } from "chart.js";
import "./WorkoutLog.css"; // Import the CSS file

Chart.register(...registerables);

const WorkoutLog = () => {
  
  const [workouts, setWorkouts] = useState([]);
  const [filteredWorkouts, setFilteredWorkouts] = useState([]);
  const [workoutType, setWorkoutType] = useState("");
  const [duration, setDuration] = useState("");
  const [caloriesBurned, setCaloriesBurned] = useState("");
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);

  const API_BASE_URL = "https://localhost:7201/api/Workout";
  const token = localStorage.getItem("token");

  useEffect(() => {
    fetchWorkouts();
  }, []);

  useEffect(() => {
    filterWorkouts();
  }, [fromDate, toDate, workouts]);

  const fetchWorkouts = async () => {
    try {
      const response = await axios.get(API_BASE_URL, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setWorkouts(response.data);
      setFilteredWorkouts(response.data);
    } catch (error) {
      console.error("Error fetching workouts:", error.response?.data || error.message);
    }
  };

  const handleAddWorkout = async (e) => {
    e.preventDefault();
    const userId = localStorage.getItem("userId");

    if (!userId) {
      console.error("User ID is missing. Ensure it's set in localStorage.");
      return;
    }

    const newWorkout = {
      userId,
      workoutType,
      duration: Number(duration),
      caloriesBurned: Number(caloriesBurned),
      date: selectedDate.toISOString(),
    };

    try {
      await axios.post(API_BASE_URL, newWorkout, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });

      fetchWorkouts();
      setWorkoutType("");
      setDuration("");
      setCaloriesBurned("");
      setSelectedDate(new Date());
    } catch (error) {
      console.error("Error adding workout:", error.response?.data || error.message);
    }
  };

  const handleDeleteWorkout = async (id) => {
    try {
      await axios.delete(`${API_BASE_URL}/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      fetchWorkouts();
    } catch (error) {
      console.error("Error deleting workout:", error.response?.data || error.message);
    }
  };

  const filterWorkouts = () => {
    if (!fromDate && !toDate) {
      setFilteredWorkouts(workouts);
      return;
    }

    const filtered = workouts.filter((workout) => {
      const workoutDate = new Date(workout.date);
      return (!fromDate || workoutDate >= fromDate) && (!toDate || workoutDate <= toDate);
    });

    setFilteredWorkouts(filtered);
  };

  const totalWorkouts = filteredWorkouts.length;
  const totalCalories = filteredWorkouts.reduce((sum, w) => sum + w.caloriesBurned, 0);
  const totalDuration = filteredWorkouts.reduce((sum, w) => sum + w.duration, 0);

  const workoutTypes = [...new Set(filteredWorkouts.map((w) => w.workoutType))];
  const caloriesData = workoutTypes.map((type) =>
    filteredWorkouts.filter((w) => w.workoutType === type).reduce((sum, w) => sum + w.caloriesBurned, 0)
  );

  const chartData = {
    labels: workoutTypes,
    datasets: [
      {
        label: "Calories Burned",
        data: caloriesData,
        backgroundColor: "rgba(54, 162, 235, 0.6)",
        borderColor: "rgba(54, 162, 235, 1)",
        borderWidth: 1,
      },
    ],
  };

  return (
    <div className="workout-container">
      <h2 className="workout-title">Workout Log</h2>

      <div className="stats-card">
        <p><strong>Total Workouts:</strong> {totalWorkouts}</p>
        <p><strong>Total Calories Burned:</strong> {totalCalories} kcal</p>
        <p><strong>Total Duration:</strong> {totalDuration} minutes</p>
      </div>

      <div className="date-filters">
        <div>
          <label>From:</label>
          <DatePicker selected={fromDate} onChange={(date) => setFromDate(date)} className="form-control" isClearable placeholderText="Start Date" />
        </div>
        <div>
          <label>To:</label>
          <DatePicker selected={toDate} onChange={(date) => setToDate(date)} className="form-control" isClearable placeholderText="End Date" />
        </div>
      </div>

      <form className="workout-form" onSubmit={handleAddWorkout}>
        <input type="text" placeholder="Workout Type (e.g., Running, Yoga)" value={workoutType} onChange={(e) => setWorkoutType(e.target.value)} required />
        <input type="number" placeholder="Duration (minutes)" value={duration} onChange={(e) => setDuration(e.target.value)} required />
        <input type="number" placeholder="Calories Burned" value={caloriesBurned} onChange={(e) => setCaloriesBurned(e.target.value)} required />
        <DatePicker selected={selectedDate} onChange={(date) => setSelectedDate(date)} className="form-control" />
        <button type="submit" className="btn-primary">Add Workout</button>
      </form>

      <table className="workout-table">
        <thead>
          <tr>
            <th>Workout Type</th>
            <th>Duration (min)</th>
            <th>Calories Burned</th>
            <th>Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {filteredWorkouts.map((workout) => (
            <tr key={workout.id}>
              <td>{workout.workoutType}</td>
              <td>{workout.duration}</td>
              <td>{workout.caloriesBurned}</td>
              <td>{new Date(workout.date).toLocaleDateString()}</td>
              <td>
                <button className="btn-danger" onClick={() => handleDeleteWorkout(workout.id)}>❌ Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="chart-container">
        <h3>Calories Burned Per Workout Type</h3>
        <Bar data={chartData} />
      </div>
    </div>
  );
};

export default WorkoutLog;
