import React, { useState, useEffect } from "react";
import axios from "axios";
import { Bar } from "react-chartjs-2";
import "chart.js/auto";
import "./Calories.css"; // ✅ Import the CSS file

const Calories = () => {
  const [calories, setCalories] = useState([]);
  const [foodItem, setFoodItem] = useState("");
  const [caloriesConsumed, setCaloriesConsumed] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [chartData, setChartData] = useState({ labels: [], datasets: [] });

  const API_BASE_URL = "https://localhost:7201/api/CalorieLog";

  useEffect(() => {
    fetchCalories();
  }, [date]);

  const fetchCalories = async () => {
    try {
      const res = await axios.get(`${API_BASE_URL}?date=${date}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("authToken")}` },
      });
      setCalories(res.data);
      prepareChartData(res.data);
    } catch (err) {
      console.error("Error fetching calorie data");
    }
  };

  const prepareChartData = (data) => {
    const labels = data.map((entry) => entry.foodItem);
    const calorieValues = data.map((entry) => entry.calories);

    setChartData({
      labels,
      datasets: [
        {
          label: "Calories",
          data: calorieValues,
          backgroundColor: "rgba(75, 192, 192, 0.6)",
          borderColor: "rgba(75, 192, 192, 1)",
          borderWidth: 1,
        },
      ],
    });
  };

  const handleAddCalorie = async (e) => {
    e.preventDefault();
    try {
      await axios.post(
        API_BASE_URL,
        { userId: localStorage.getItem("userId"), foodItem, calories: parseInt(caloriesConsumed), date },
        { headers: { Authorization: `Bearer ${localStorage.getItem("authToken")}` } }
      );
      fetchCalories();
      setFoodItem("");
      setCaloriesConsumed("");
    } catch (err) {
      console.error("Error adding calorie entry");
    }
  };

  return (
    <div className="container mt-4">
      <div className="calorie-card shadow-lg p-4 rounded">
        <h2 className="text-center title">Calorie Tracker</h2>
        <hr />
        <div className="mb-3">
          <label className="form-label">Select Date:</label>
          <input type="date" className="form-control" value={date} onChange={(e) => setDate(e.target.value)} />
        </div>

        <h3 className="calorie-total">Total Calories: {calories.reduce((sum, entry) => sum + entry.calories, 0)} kcal</h3>

        <form className="mb-4 calorie-form" onSubmit={handleAddCalorie}>
          <input type="text" className="form-control" placeholder="Food Item" value={foodItem} onChange={(e) => setFoodItem(e.target.value)} required />
          <input type="number" className="form-control" placeholder="Calories" value={caloriesConsumed} onChange={(e) => setCaloriesConsumed(e.target.value)} required />
          <button type="submit" className="btn btn-success w-100 add-btn">Add Calorie</button>
        </form>

        <h3>Calorie History</h3>
        <ul className="list-group calorie-list">
          {calories.map((entry) => (
            <li key={entry.id} className="list-group-item d-flex justify-content-between align-items-center">
              {entry.foodItem} - <span className="fw-bold">{entry.calories} kcal</span>
              <button className="btn btn-danger btn-sm delete-btn" onClick={() => fetchCalories(entry.id)}>Delete</button>
            </li>
          ))}
        </ul>

        <h3 className="mt-4">Calorie Trend</h3>
        <div className="chart-container">
          <Bar data={chartData} />
        </div>
      </div>
    </div>
  );
};

export default Calories;
